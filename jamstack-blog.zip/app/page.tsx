import Header from "@/components/header"
import ProfileCard from "@/components/profile-card"
import BlogPostList from "@/components/blog-post-list"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <div className="container mx-auto px-4 py-8">
        <Header />
        <div className="mt-12 max-w-3xl mx-auto">
          <ProfileCard />
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-8">Recent Posts</h2>
            <BlogPostList />
          </div>
        </div>
        <Footer />
      </div>
    </main>
  )
}

