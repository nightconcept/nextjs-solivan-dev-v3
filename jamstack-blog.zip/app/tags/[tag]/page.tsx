import Header from "@/components/header"
import Footer from "@/components/footer"
import Breadcrumb from "@/components/breadcrumb"
import { blogPosts } from "@/components/blog-post-list"
import Link from "next/link"

export default function TagPage({ params }: { params: { tag: string } }) {
  const tag = params.tag.replace(/-/g, " ")
  const formattedTag = tag
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  const filteredPosts = blogPosts.filter((post) => post.tags.some((t) => t.toLowerCase() === tag.toLowerCase()))

  return (
    <main className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <div className="container mx-auto px-4 py-8">
        <Header />
        <div className="mt-8 max-w-3xl mx-auto">
          <Breadcrumb
            items={[
              { label: "Home", href: "/" },
              { label: "Blog", href: "/blog" },
              { label: `Tag: ${formattedTag}`, href: `/tags/${params.tag}` },
            ]}
          />

          <h1 className="text-3xl font-bold mt-8 mb-6">Posts tagged with "{formattedTag}"</h1>

          {filteredPosts.length > 0 ? (
            <div className="space-y-8">
              {filteredPosts.map((post) => (
                <article key={post.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                  <Link href={`/blog/${post.id}`}>
                    <h3 className="text-xl font-bold mb-2 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                      {post.title}
                    </h3>
                  </Link>
                  <p className="text-gray-700 dark:text-gray-300 mb-4">{post.excerpt}</p>
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <span>{post.date}</span>
                    <span className="mx-2">•</span>
                    <span>{post.readTime} read</span>
                    <span className="mx-2">•</span>
                    <span>By {post.author}</span>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <p>No posts found with this tag.</p>
          )}
        </div>
        <Footer />
      </div>
    </main>
  )
}

