import Header from "@/components/header"
import Footer from "@/components/footer"
import Breadcrumb from "@/components/breadcrumb"
import { blogPosts } from "@/components/blog-post-list"
import Link from "next/link"

export default function BlogPost({ params }: { params: { id: string } }) {
  const postId = Number.parseInt(params.id)
  const post = blogPosts.find((post) => post.id === postId)

  if (!post) {
    return (
      <main className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <div className="container mx-auto px-4 py-8">
          <Header />
          <div className="mt-12 max-w-3xl mx-auto">
            <h1 className="text-3xl font-bold mb-8">Post Not Found</h1>
            <p>Sorry, the blog post you're looking for doesn't exist.</p>
            <Link href="/blog" className="text-primary hover:underline mt-4 inline-block">
              Back to Blog
            </Link>
          </div>
          <Footer />
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <div className="container mx-auto px-4 py-8">
        <Header />
        <div className="mt-8 max-w-3xl mx-auto">
          <Breadcrumb
            items={[
              { label: "Home", href: "/" },
              { label: "Blog", href: "/blog" },
            ]}
          />

          <article className="mt-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{post.title}</h1>

            <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-8">
              <span>{post.date}</span>
              <span className="mx-2">•</span>
              <span>{post.readTime} read</span>
              <span className="mx-2">•</span>
              <span>By {post.author}</span>
            </div>

            <div className="prose dark:prose-invert max-w-none lg:prose-lg">
              <p>
                JAMStack is revolutionizing how we build websites by focusing on JavaScript, APIs, and Markup. This
                approach offers numerous benefits including improved performance, higher security, and better developer
                experience.
              </p>

              <p>
                When you build a JAMStack site, you're essentially pre-building all the pages during a build process.
                This means that instead of generating pages on-demand when users request them (like in traditional
                server-rendered applications), your pages are already built and ready to serve.
              </p>

              <h2>Why JAMStack?</h2>

              <p>There are several compelling reasons to consider JAMStack for your next project:</p>

              <ul>
                <li>
                  <strong>Performance</strong>: Pre-rendered pages can be served directly from a CDN, resulting in
                  extremely fast load times.
                </li>
                <li>
                  <strong>Security</strong>: With no server-side processes, there's a significantly reduced attack
                  surface.
                </li>
                <li>
                  <strong>Scalability</strong>: Static assets can be served from CDNs globally, making scaling
                  effortless.
                </li>
                <li>
                  <strong>Developer Experience</strong>: The clear separation of frontend and backend concerns leads to
                  a more streamlined development process.
                </li>
              </ul>

              <p>
                If you're interested in learning more, check out{" "}
                <a href="https://jamstack.org" className="text-primary hover:text-primary-dark underline">
                  jamstack.org
                </a>{" "}
                for comprehensive resources and examples.
              </p>

              <h2>Getting Started</h2>

              <p>
                To get started with JAMStack, you'll need to choose a static site generator. Some popular options
                include:
              </p>

              <ul>
                <li>
                  <a href="https://nextjs.org" className="text-primary hover:text-primary-dark underline">
                    Next.js
                  </a>{" "}
                  - A React framework with both static and server-rendered capabilities
                </li>
                <li>
                  <a href="https://www.gatsbyjs.com" className="text-primary hover:text-primary-dark underline">
                    Gatsby
                  </a>{" "}
                  - A React-based framework focused on static sites
                </li>
                <li>
                  <a href="https://nuxtjs.org" className="text-primary hover:text-primary-dark underline">
                    Nuxt.js
                  </a>{" "}
                  - A Vue.js framework similar to Next.js
                </li>
                <li>
                  <a href="https://gohugo.io" className="text-primary hover:text-primary-dark underline">
                    Hugo
                  </a>{" "}
                  - A fast static site generator written in Go
                </li>
              </ul>

              <p>
                Once you've chosen your framework, you can start building your site and deploying it to platforms like
                Vercel, Netlify, or GitHub Pages.
              </p>
            </div>

            <div className="mt-12 pt-6 border-t border-gray-200 dark:border-gray-800">
              <h3 className="text-lg font-medium mb-4">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {post.tags.map((tag, index) => (
                  <Link
                    key={index}
                    href={`/tags/${tag.toLowerCase().replace(/\s+/g, "-")}`}
                    className="bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 px-3 py-1 rounded-md text-sm transition-colors"
                  >
                    {tag}
                  </Link>
                ))}
              </div>
            </div>
          </article>
        </div>
        <Footer />
      </div>
    </main>
  )
}

