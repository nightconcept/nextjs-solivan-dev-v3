export default function Footer() {
  return (
    <footer className="py-6 mt-12">
      <div className="max-w-2xl mx-auto px-4 border-t border-gray-200 dark:border-gray-800 pt-6">
        <p className="text-xs text-gray-500 dark:text-gray-400 text-center">&copy; Danny 2007-2025</p>
      </div>
    </footer>
  )
}

